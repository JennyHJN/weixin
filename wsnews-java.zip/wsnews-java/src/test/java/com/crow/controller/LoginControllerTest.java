package com.crow.controller;

/**
 * Created by wangyq1
 */
//@RunWith(SpringRunner.class)
//@SpringBootTest
public class LoginControllerTest {
//    private MockMvc mockMvc;

//    @Before
//    public void setUp(){
//        mockMvc= MockMvcBuilders.standaloneSetup(new LoginController()).build();
//    }

//    @Test
//    public void testLogin() throws Exception {
//        ResultActions response=mockMvc.perform(MockMvcRequestBuilders.post("/wsnews/silentLogin")
//                .param("code","XXX","男"));
//        System.out.println("xx");
//    }
}
