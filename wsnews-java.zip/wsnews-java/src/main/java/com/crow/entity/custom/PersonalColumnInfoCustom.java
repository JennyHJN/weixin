package com.crow.entity.custom;

public class PersonalColumnInfoCustom {
    private Integer columnId;
    private String columnName;
    private Integer algorithmCount;

    public Integer getColumnId() {
        return columnId;
    }

    public void setColumnId(Integer columnId) {
        this.columnId = columnId;
    }

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public Integer getAlgorithmCount() {
        return algorithmCount;
    }

    public void setAlgorithmCount(Integer algorithmCount) {
        this.algorithmCount = algorithmCount;
    }
}
