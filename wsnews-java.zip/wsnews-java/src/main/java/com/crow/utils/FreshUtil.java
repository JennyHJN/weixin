package com.crow.utils;

public class FreshUtil {
    public static Integer freshline;
}
