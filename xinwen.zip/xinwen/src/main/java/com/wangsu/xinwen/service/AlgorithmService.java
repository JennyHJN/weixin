package com.wangsu.xinwen.service;

import com.wangsu.xinwen.mapper.AlgorithmMapper;
import com.wangsu.xinwen.mapper.ColumnAlgorithmMapper;
import com.wangsu.xinwen.mapper.ColumnMapper;
import com.wangsu.xinwen.mapper.UserColumnMapper;
import com.wangsu.xinwen.pojo.Algorithm;
import com.wangsu.xinwen.pojo.ColumnAlgorithm;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AlgorithmService {
    @Resource
    private AlgorithmMapper algorithmMapper;
    @Resource
    private ColumnAlgorithmMapper columnAlgorithmMapper;
    @Resource
    private ColumnMapper columnMapper;
    @Resource
    private UserColumnMapper userColumnMapper;

    /***
     *根据栏目Id和用户Id获取算法列表（只显示该栏目已经应用的算法列表，也就是status为1的）
     * 入参一个judge，如果judge为1则要判断status，status为1的才返回给前端；judge为0则不管status状态如何全给前端
     * @author hjn
     * @date 2019/8/10
     * @param columnId
     * @param userId
     * @param judge
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     */
    public List<Map<String, Object>> getAllAlgorithmsByColumnId(int columnId, String userId, int judge){
        //根据Map进行查询
        Map<String, Object> map = new HashMap<>();
        map.put("column_id", columnId);
        map.put("user_id", userId);
        List<ColumnAlgorithm> columnAlgorithms = columnAlgorithmMapper.selectByMap(map);
        if (columnAlgorithms == null || columnAlgorithms.size() == 0){
            return null;
        }

        List<Map<String, Object>> algorithmsMap = new ArrayList<>();
        for (ColumnAlgorithm columnAlgorithm: columnAlgorithms){
            int algorithmId = columnAlgorithm.getAlgorithmId();
            boolean status = columnAlgorithm.getStatus();
            Map<String, Object> algorithmMap = new HashMap<>();
            Algorithm algorithm = algorithmMapper.selectById(algorithmId);
            algorithmMap.put("algorithmId", algorithmId);
            algorithmMap.put("algorithmName", algorithm.getName());
            algorithmMap.put("contributor", algorithm.getContributor());
            algorithmMap.put("useRate", algorithm.getUseRate());
            algorithmMap.put("tagName", algorithm.getType().split(","));//tagName是算法数据库中的type字段
            algorithmMap.put("status", status);
            if (judge == 1) {
                if (status == true){
                    algorithmsMap.add(algorithmMap);
                }
            }else {
                algorithmsMap.add(algorithmMap);
            }
        }
        return algorithmsMap;
    }
    /**
     *根据栏目Id和用户Id获取算法列表（不管status是不是为true）
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     */
    public List<Map<String, Object>> getAllAlgorithms(int columnId, String userId){
        List<Map<String, Object>> algorithmsMap = getAllAlgorithmsByColumnId(columnId, userId, 0);
        return algorithmsMap;
    }


    /**
     *算法详情
     * @author hjn
     * @date 2019/8/10
     * @param algorithmId
     * @param userId
     * @param columnId
     * @return java.util.Map<java.lang.String,java.lang.Object>
     * 根据算法Id和用户Id获取到栏目Id，并且根据栏目Id、算法Id、栏目Id去找status
     * status为1则获取对应的栏目Name，status为0则不获取对应的栏目Name
     */
    public Map<String, Object> getAlgorithmById(String algorithmId, String userId, String columnId){
        List<Integer> columnIds = columnAlgorithmMapper.getColumnIds(Integer.parseInt(algorithmId), userId);
        List<String> columnNames = new ArrayList<>();
        for (int colId: columnIds){
            int colStatus = columnAlgorithmMapper.getStatus(colId, Integer.parseInt(algorithmId), userId);
            String columnName = columnMapper.selectById(colId).getName();
            if (colStatus == 1){
                columnNames.add(columnName);
            }
        }

        int status = columnAlgorithmMapper.getStatus(Integer.parseInt(columnId), Integer.parseInt(algorithmId), userId);
        Algorithm algorithm = algorithmMapper.selectById(algorithmId);

        Map<String, Object> algorithmMap = new HashMap<>();
        algorithmMap.put("algorithmName", algorithm.getName());
        algorithmMap.put("updateTime", algorithm.getTime().getTime());
        algorithmMap.put("contributor", algorithm.getContributor());
        algorithmMap.put("useRate", algorithm.getUseRate());
        algorithmMap.put("columnName", columnNames);
        algorithmMap.put("type", algorithm.getType());
        algorithmMap.put("details", algorithm.getDetails());
        if(status==1){
            algorithmMap.put("status",true);
        }else{
            algorithmMap.put("status",false);
        }

        return algorithmMap;
    }


    /**
     *栏目算法应用与取消应用
     * @author hjn
     * @date 2019/8/11
     * @param columnId
     * @param userId
     * @param algorithmId
     * @param status
     * @return boolean
     */
    public boolean updateColAlgoStatus(int columnId, String userId, Integer algorithmId, String status){
        //根据Map进行查询
        Map<String, Object> map = new HashMap<>();
        map.put("column_id",columnId);
        map.put("algorithm_id",algorithmId);
        map.put("user_id",userId);
        int colAlgoId = columnAlgorithmMapper.selectByMap(map).get(0).getId();

        ColumnAlgorithm columnAlgorithm = new ColumnAlgorithm();
        columnAlgorithm.setId(colAlgoId);
        columnAlgorithm.setColumnId(columnId);
        columnAlgorithm.setUserId(userId);
        columnAlgorithm.setAlgorithmId(algorithmId);

        if (status.equals("true")){
            columnAlgorithm.setStatus(true);
        }else{
            columnAlgorithm.setStatus(false);
        }

        Integer success = columnAlgorithmMapper.updateById(columnAlgorithm);
        if (success == 0 || success == null){
            return false;
        }
        return true;
    }

}
