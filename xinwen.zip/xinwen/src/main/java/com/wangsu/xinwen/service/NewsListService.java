package com.wangsu.xinwen.service;


import com.wangsu.xinwen.mapper.*;
import com.wangsu.xinwen.pojo.Column;
import com.wangsu.xinwen.pojo.News;
import com.wangsu.xinwen.utils.GetAi;
import com.wangsu.xinwen.utils.GetImgUrlUtil;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NewsListService {

    @Resource
    private NewsMapper newsMapper;

    @Resource
    private ColumnMapper columnMapper;

    @Resource
    private CommentMapper commentMapper;

    @Resource
    private ColumnAlgorithmMapper columnAlgorithmMapper;

    /**
     *根据栏目Id和用户Id返回对应的新闻列表（分页）
     * userId为null则是游客状态，userId设置为默认的，"666666"
     * @author xzp
     * @date 2019/8/8
     * @param columnId
     * @param start
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult getNewsListByColumnId(int columnId, int start, String userId) {
        Column column=columnMapper.selectById(columnId);
        String columnName = column.getName();
        List<Integer> res;
        if (userId.equals("") || userId == null){
            String[] algorithmId = columnAlgorithmMapper.getAlgorithmIdByUserId(columnId,"666666");
            res= GetAi.getNewsListByAi(algorithmId[0],columnName,"666666");
        }else{
            String[] algorithmId = columnAlgorithmMapper.getAlgorithmIdByUserId(columnId,userId);
            if(algorithmId.equals("")||algorithmId==null) {
                res= GetAi.getNewsListByAi("1",columnName,userId);
            }else{
                res= GetAi.getNewsListByAi(algorithmId[0],columnName,userId);
            }

        }
        List<News> newsList=newsMapper.selectBatchIds(res);
        List<Map> result = new ArrayList<>();

        for(int i = start*10; i < newsList.size() && i<=start*10+10; i++){

            Map temp=new HashMap<String,Object>();
            int commentCount =commentMapper.CountNumber(newsList.get(i).getId());
            temp.put("commentCount",commentCount);
            temp.put("newsId",newsList.get(i).getId());
            temp.put("title",newsList.get(i).getTitle());
            temp.put("source",newsList.get(i).getSource());
            temp.put("time",newsList.get(i).getTime().getTime());
            String imgName = newsList.get(i).getImgId();
            ArrayList<String> imgURL = GetImgUrlUtil.getImgURL(imgName);
            if(imgURL == null || imgURL.size() == 0){
                temp.put("imgId", imgURL);
            }else{
                temp.put("imgId",imgURL.get(0));
            }
            result.add(temp);
        }

        return GlobalResult.build(200, null, result);
    }

    /**
     *根据新闻Id和用户Id返回相关新闻列表（三条）
     * userId为null则是游客状态，userId设置为默认的，"666666"
     * @author xzp
     * @date 2019/8/8
     * @param newsId
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult getRelationNewsById(int newsId, String userId){
        List<Integer> res;
        if(userId.equals("")||userId==null){
            res= GetAi.getNewsListByAi("2",newsMapper.selectById(newsId).getTagName(),"666666");
        }else{
            res= GetAi.getNewsListByAi("2",newsMapper.selectById(newsId).getTagName(),userId);
        }

        List<News> newsList=newsMapper.selectBatchIds(res);
        List<Map> result = new ArrayList<>();

        for(int i = 0; i < 3; i++){
            Map temp=new HashMap<String,Object>();
            int commentCount =commentMapper.CountNumber(newsList.get(i).getId());
            temp.put("title",newsList.get(i).getTitle());
            temp.put("source",newsList.get(i).getSource());
            temp.put("time",newsList.get(i).getTime().getTime());
            temp.put("commentCount",commentCount);
            temp.put("newsId",newsList.get(i).getId());

            String imgName = newsList.get(i).getImgId();
            ArrayList<String> imgURL = GetImgUrlUtil.getImgURL(imgName);
            if(imgURL == null || imgURL.size() == 0){
                temp.put("imgId",imgURL);
            }else{
                temp.put("imgId",imgURL.get(0));
            }
            result.add(temp);
        }

        return GlobalResult.build(200, null, result);
    }
}
