package com.wangsu.xinwen.service;

import com.wangsu.xinwen.mapper.LikeMapper;
import com.wangsu.xinwen.pojo.Like;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LikeService {
    @Resource
    private LikeMapper likeMapper;

    /**
     *点赞
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param userId
     * @return boolean
     */
    public boolean addLike(int newsId, String userId){
        Like like = new Like();
        like.setNewsId(newsId);
        like.setUserId(userId);
        Map<String,Object> map=new HashMap();
        map.put("news_id",newsId);
        map.put("user_id",userId);

        List<Like> news=likeMapper.selectByMap(map);
        if (news!=null){
            Integer result = likeMapper.insert(like); //影响数据库行数，为0表示插入不成功
            if (result != null || result > 0) {
                return true;
            }
        }

        return false;
    }

    /**
     *取消点赞
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param userId
     * @return boolean
     */
    public boolean deleteLike(int newsId, String userId){
        //根据Map条件删除
        Map<String, Object> map = new HashMap<>();
        map.put("user_id", userId);
        map.put("news_id", newsId);

        Integer result = likeMapper.deleteByMap(map);
        if (result != null || result > 0) {
            return true;
        }
        return false;

    }
}
