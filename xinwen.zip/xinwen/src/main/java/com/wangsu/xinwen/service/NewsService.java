package com.wangsu.xinwen.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.wangsu.xinwen.mapper.*;
import com.wangsu.xinwen.pojo.News;
import com.wangsu.xinwen.utils.GlobalResult;
import com.wangsu.xinwen.utils.GetImgUrlUtil;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.*;


@Service
public class NewsService {
    @Resource
    private NewsMapper newsMapper;
    @Resource
    private CommentMapper commentMapper;
    @Resource
    private CollectionMapper collectionMapper;
    @Resource
    private LikeMapper likeMapper;

    /**
     *根据新闻Id返回对应的新闻详情信息
     * @author hjn
     * @date 2019/8/8
     * @author xzp
     * @date 2019/8/10
     * @param newsId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult getNewsById(int newsId, String userId) {
        News news = newsMapper.selectById(newsId);
        news.setHeat(news.getHeat()+1);
        LambdaQueryWrapper<News> query = new LambdaQueryWrapper<>();
        query.eq(News::getId,newsId);
        newsMapper.update(news,query );
        if (news == null){
            return GlobalResult.build(500, "此条新闻不存在！", null);
        }
        String imgName = news.getImgId();
        ArrayList<String> imgURL = GetImgUrlUtil.getImgURL(imgName);
        Map<String, Object> newsMap = new HashMap<>();
        newsMap.put("title", news.getTitle());
        newsMap.put("source", news.getSource());
        newsMap.put("time", news.getTime().getTime());
        newsMap.put("imgId", imgURL);
        newsMap.put("content", news.getContent());
        newsMap.put("keyName", news.getKeyName());
        int commentCount =commentMapper.CountNumber(newsId);
        newsMap.put("commentCount",commentCount);
        GlobalResult res = GlobalResult.build(200, null, newsMap);

        int isLike =likeMapper.getStatus(newsId,userId);
        if(isLike==0){
            newsMap.put("praiseStatus", 0);
        }else{
            newsMap.put("praiseStatus", 1);
        }
        int isCollection =collectionMapper.getStatus(newsId,userId);
        if(isCollection==0){
            newsMap.put("favorStatus", 0);
        }else{
            newsMap.put("favorStatus", 1);
        }
        return res;
    }
}
