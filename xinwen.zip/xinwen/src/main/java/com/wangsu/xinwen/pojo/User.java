package com.wangsu.xinwen.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;


@Data
@TableName("user")
@ToString
public class User {
    private static final long serialVersionUID = 1L;
    /**
     * open_id 用户唯一标识
     */
    @TableId(value = "id", type = IdType.INPUT)
    private String openId;
    /**
     * 网名
     */
    @TableField("name")
    private String name;
    /**
     * skey 会话密匙
     */
    @TableField("skey")
    private String skey;
    /**
     * 创建时间
     */
    @TableField("create_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createTime;
    /**
     * 最后登录时间
     */
    @TableField("last_visit_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date lastVisitTime;
    /**
     * session_key
     */
    @TableField("session_key")
    private String sessionKey;
}
