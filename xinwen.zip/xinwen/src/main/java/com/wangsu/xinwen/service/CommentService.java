package com.wangsu.xinwen.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.wangsu.xinwen.mapper.CommentMapper;
import com.wangsu.xinwen.mapper.UserMapper;
import com.wangsu.xinwen.pojo.Comment;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommentService {
    @Resource
    private CommentMapper commentMapper;
    @Resource
    private UserMapper userMapper;

    /**
     *根据新闻Id和usrId返回对应的用户信息和相关的评论信息（分页）
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param start
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult getCommentsById(int newsId, int start) {

        Page<Comment> pageParam = new Page<>(start, 100); // 当前页码，每页条数
        LambdaQueryWrapper<Comment> query = new LambdaQueryWrapper<>();
        query.getSqlSelect();
        query.eq(Comment::getNewsId,newsId);
        IPage<Comment> pageResult = commentMapper.selectPage(pageParam, query);
        List<Comment> commentList =  pageResult.getRecords();
        List<Map<String, Object>> commentMaps = new ArrayList<>();
        for (Comment comment: commentList) {
            Map<String, Object> commentMap = new HashMap<>();
            String userId = comment.getUserId();
            String userName = userMapper.selectById(userId).getName();
            commentMap.put("userId", userId);
            commentMap.put("userName", userName);
            commentMap.put("time", comment.getTime().getTime());
            commentMap.put("comment", comment.getContent());
            commentMap.put("commentId", comment.getId());
            commentMaps.add(commentMap);
        }

        GlobalResult res = GlobalResult.build(200, null, commentMaps);
        return res;
    }
    /**
     *添加评论
     * @author hjn
     * @date 2019/8/10
     * @param content
     * @param newsId
     * @param time
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult addComment(String content, int newsId, Long time, String userId){
        if(userId==null||content==null)return null;
        Comment comment = new Comment();
        comment.setContent(content);
        comment.setNewsId(newsId);
        comment.setTime(new Timestamp(time));
        comment.setUserId(userId);
        int success = commentMapper.insert(comment);
        GlobalResult res = new GlobalResult();
        if (success != 0){
            res.build(200, "添加评论成功", null);
        }else{
            res.build(500, "添加评论失败", null);
        }
        return res;
    }

    /**
     *删除评论
     * @author hjn
     * @date 2019/8/10
     * @param commentId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    public GlobalResult deleteComment( int commentId){

        int success = commentMapper.deleteById(commentId);
        GlobalResult res = new GlobalResult();
        if (success != 0){
            res.build(200, "删除评论成功", null);
        }else{
            res.build(500, "删除评论失败", null);
        }
        return res;
    }
}
