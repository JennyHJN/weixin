package com.wangsu.xinwen.controller;

import com.wangsu.xinwen.service.AlgorithmService;
import com.wangsu.xinwen.service.ColumnService;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;



@RestController
@RequestMapping("/columns")
public class ColumnController {
    @Resource
    private ColumnService columnService;

    @Resource
    AlgorithmService algorithmService;

    /**
     *根据用户Id获取到用户定制化的栏目名（多个）
     * @author hjn
     * @date 2019/8/9
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllColumns", method = RequestMethod.POST)
    public GlobalResult getAllColumns(@RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = columnService.getAllColumns(userId);
        return res;
    }

    /**
     *栏目算法应用与取消应用
     * @author hjn
     * @date 2019/8/11
     * @param columnId
     * @param userId
     * @param algorithmId
     * @param status
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping("/editAlgorithmByColumnId")
    public GlobalResult editAlgorithmByColumnId(@RequestParam(value = "columnId", required = false) Integer columnId,
                                                @RequestParam(value = "userId", required = false) String userId,
                                                @RequestParam(value = "algorithmId", required = false) Integer algorithmId,
                                                @RequestParam(value = "status", required = false) String status){
        GlobalResult res = new GlobalResult();
        boolean success = algorithmService.updateColAlgoStatus(columnId, userId, algorithmId, status);

        String msg;
        Integer sta;
        if (success == false){
            msg = "栏目算法应用与取消应用失败";
            sta = 500;
        }else{
            msg = "栏目算法应用与取消应用成功";
            sta = 200;
        }
        res = res.build(sta, msg, null);
        return res;
    }

}
