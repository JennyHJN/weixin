package com.wangsu.xinwen.controller;

import com.wangsu.xinwen.service.*;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/news")
public class NewsController {
    @Autowired
    private NewsService newsService;
    @Autowired
    private RecordService recordService;
    @Resource
    private CommentService commentService;
    @Resource
    private CollectionService collectionService;
    @Resource
    private LikeService likeService;

    /**
     *根据新闻Id获取到单条新闻的详细信息并插入新闻Id和用户Id到record表
     * @author hjn
     * @date 2019/8/8
     * @param newsId, userId
     * @return
     */
    @RequestMapping(value = "/getNewsById", method = RequestMethod.POST)
    public GlobalResult getNewsById(@RequestParam(value = "newsId", required = false) Integer newsId,
                                    @RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = newsService.getNewsById(newsId,userId);
        if (userId != null && userId != "" && userId.length() != 0) {
            boolean success = recordService.addRecord(newsId, userId);
            if (success == false) {
                //
                System.out.println("newsId和userId加入record表失败!");
            }
        }
        return res;
    }

    /**
     *根据新闻Id和usrId返回对应的用户信息和相关的评论信息（分页）
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param start
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getCommentsById", method = RequestMethod.POST)
    public GlobalResult getCommentsById(@RequestParam(value = "newsId", required = false) Integer newsId,
                                        @RequestParam(value = "start", required = false) Integer start){

        GlobalResult res = commentService.getCommentsById(newsId, start);
        return res;
    }

    /**
     *添加评论
     * @author hjn
     * @date 2019/8/10
     * @param content
     * @param newsId
     * @param time
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/addComment", method = RequestMethod.POST)
    public GlobalResult addComment(@RequestParam(value = "comment", required = false) String content,
                                   @RequestParam(value = "newsId", required = false) Integer newsId,
                                   @RequestParam(value = "time", required = false) Long  time,
                                   @RequestParam(value = "userId", required = false) String userId
                                   ){
        GlobalResult res = commentService.addComment(content, newsId, time, userId);
        return res;
    }

    /**
     *删除评论
     * @author xzp
     * @date 2019/8/10
     * @param commentId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/deleteComment", method = RequestMethod.POST)
    public GlobalResult addComment(@RequestParam(value = "commentId", required = false) Integer commentId){
        GlobalResult res = commentService.deleteComment(commentId);
        return res;
    }

    /**
     *用户收藏或取消收藏新闻操作
     * @author hjn
     * @date 2019/8/11
     * @param newsId
     * @param status
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/editFavor", method = RequestMethod.POST)
    public GlobalResult editFavor(@RequestParam(value = "newsId", required = false) Integer newsId,
                                  @RequestParam(value = "status", required = false) String status,
                                  @RequestParam(value = "userId") String userId){

        GlobalResult res = new GlobalResult();
        //如果status = 1 用户要收藏这条新闻 status = 0为用户要取消收藏
        if (status.equals("1")){
            //如果用户要收藏这条新闻，那么就是要在collection数据表中增加一条记录
            boolean addFlag = collectionService.addCollection(newsId, userId);
            String msg;
            if (addFlag == false){
                msg = "您已收藏过此条新闻或收藏失败";
            }else{
                msg = "收藏成功";
            }
            res.build(200, msg, null);

        }else{
            //如果用户要取消收藏这条新闻，那么就是要在collection数据表中减少一条对应的记录
            boolean delFlag = collectionService.deleteCollection(newsId, userId);
            String msg;
            if (delFlag == false){
                msg = "取消收藏失败！";
            }else{
                msg = "取消收藏成功！";
            }
            res.build(200, msg, null);
        }
        return res;
    }

    /**
     *用户点赞或取消点赞新闻操作
     * @author hjn
     * @date 2019/8/11
     * @param newsId
     * @param status
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/editPraise", method = RequestMethod.POST)
    public GlobalResult editPraise(@RequestParam(value = "newsId", required = false) Integer newsId,
                                   @RequestParam(value = "status", required = false) String status,
                                   @RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        //如果status = 1 用户要点赞这条新闻 status = 0为用户要取消点赞
        if (status.equals("1")){
            //如果用户要点赞这条新闻，那么就是要在like数据表中增加一条记录
            boolean addFlag = likeService.addLike(newsId, userId);
            String msg="";
            if (addFlag == false){
                msg = "不能重复点赞或点赞失败";
            }else{
                msg = "点赞成功";
            }
            res.build(200, msg, null);

        }else{
            //如果用户要取消点赞这条新闻，那么就是要在like数据表中减少一条对应的记录
            boolean delFlag = likeService.deleteLike(newsId, userId);
            String msg;
            if (delFlag == false){
                msg = "取消点赞失败！";
            }else{
                msg = "取消点赞成功！";
            }
            res.build(200, msg, null);
        }
        return res;
    }
}
