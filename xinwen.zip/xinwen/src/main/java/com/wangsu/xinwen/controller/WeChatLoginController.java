package com.wangsu.xinwen.controller;

import com.wangsu.xinwen.utils.GlobalResult;
import com.wangsu.xinwen.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class WeChatLoginController {
    @Autowired
    private UserService userService;


    /**
     *用户登录操作
     * @author xzp
     * @date 2019/8/6
     * @param code
     * @param rawData
     * @param signature
     * @param encrypteData
     * @param iv
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @PostMapping("/login")
    @ResponseBody
    public GlobalResult login(@RequestParam("code") String code,
                              @RequestParam(value = "rawData", required = false) String rawData,
                              @RequestParam(value = "signature", required = false) String signature,
                              @RequestParam(value = "encrypteData", required = false) String encrypteData,
                              @RequestParam(value = "iv", required = false) String iv) {
        GlobalResult res = userService.login(code, rawData, signature, encrypteData, iv);
        return res;
    }
}
