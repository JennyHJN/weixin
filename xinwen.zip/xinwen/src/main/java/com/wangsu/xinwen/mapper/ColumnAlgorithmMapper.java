package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.ColumnAlgorithm;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface ColumnAlgorithmMapper extends BaseMapper<ColumnAlgorithm> {

    @Select("select status from column_algorithm where column_id = #{columnId} and algorithm_id = #{algorithmId} and user_id = #{userId}")
    int getStatus(int columnId, int algorithmId, String userId);

    @Select("select column_id from column_algorithm where algorithm_id = #{algorithmId} and user_id = #{userId}")
    List<Integer> getColumnIds(int algorithmId, String userId);

    @Select("select algorithm_id from column_algorithm where column_id = #{columnId} and user_id = #{userId}")
    String[] getAlgorithmIdByUserId(int columnId, String userId);
}
