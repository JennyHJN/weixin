package com.wangsu.xinwen.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.wangsu.xinwen.mapper.*;
import com.wangsu.xinwen.pojo.*;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MyService {
    @Resource
    private CollectionMapper collectionMapper;
    @Resource
    private NewsMapper newsMapper;
    @Resource
    private LikeMapper likeMapper;
    @Resource
    private CommentMapper commentMapper;
    @Resource
    private UserMapper userMapper;

    /**
     *根据userId获得用户收藏的的新闻
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     */
    public List<Map<String, Object>> getAllFavor(String userId){
        List<Integer> newsIds = collectionMapper.getNewsIdByUserId(userId);
        List<Map<String, Object>> allFavors = new ArrayList<>();
        for (int newsId : newsIds){
            News news = newsMapper.selectById(newsId);

            Map<String, Object> favorMap = new HashMap<>();
            favorMap.put("title", news.getTitle());
            favorMap.put("source", news.getSource());
            favorMap.put("time", news.getTime().getTime());
            favorMap.put("imgId", news.getImgId().split(","));
            favorMap.put("newsId", newsId);

            QueryWrapper<Collection> favorWrapper = new QueryWrapper<>();
            favorWrapper.eq("news_id", newsId);
            int favorNum = collectionMapper.selectCount(favorWrapper);
            favorMap.put("favorNum", favorNum);

            QueryWrapper<Like> praiseWrapper = new QueryWrapper<>();
            praiseWrapper.eq("news_id", newsId);
            int praiseNum = likeMapper.selectCount(praiseWrapper);
            favorMap.put("praiseNum", praiseNum);

            QueryWrapper<Comment> commentWrapper = new QueryWrapper<>();
            commentWrapper.eq("news_id", newsId);
            int commentNum = commentMapper.selectCount(commentWrapper);
            favorMap.put("commentNum", commentNum);
            allFavors.add(favorMap);
        }
        return allFavors;
    }

    /**
     *根据userId获得用户点赞的新闻
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     */
    public List<Map<String, Object>> getAllPraise(String userId){
        List<Map<String, Object>> allPraises = new ArrayList<>();
        List<Integer> newsIds = likeMapper.getNewsIdByUserId(userId);

        for (int newsId : newsIds){
            News news = newsMapper.selectById(newsId);

            Map<String, Object> praiseMap = new HashMap<>();
            praiseMap.put("source", news.getSource());
            praiseMap.put("time", news.getTime().getTime());
            praiseMap.put("title", news.getTitle());
            praiseMap.put("newsId", newsId);
            praiseMap.put("imgId", news.getImgId().split(","));

            QueryWrapper<Comment> commentWrapper = new QueryWrapper<>();
            commentWrapper.eq("news_id", newsId);
            int commentNum = commentMapper.selectCount(commentWrapper);
            praiseMap.put("commentNum", commentNum);

            QueryWrapper<Like> praiseWrapper = new QueryWrapper<>();
            praiseWrapper.eq("news_id", newsId);
            int praiseNum = likeMapper.selectCount(praiseWrapper);
            praiseMap.put("praiseNum", praiseNum);

            QueryWrapper<Collection> favorWrapper = new QueryWrapper<>();
            favorWrapper.eq("news_id", newsId);
            int favorNum = collectionMapper.selectCount(favorWrapper);
            praiseMap.put("favorNum", favorNum);

            allPraises.add(praiseMap);
        }
        return allPraises;
    }

    /**
     *根据userId获得用户的评论和对应的新闻标题
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
     */
    public List<Map<String, Object>> getAllComment(String userId){
        List<Map<String, Object>> allComments = new ArrayList<>();
        List<Integer> newsIds = commentMapper.getNewsIdByUserId(userId);

        for (int newsId : newsIds){
            News news = newsMapper.selectById(newsId);
            User user = userMapper.selectById(userId);

            Map<String, Object> colMap = new HashMap<>();
            colMap.put("news_id", newsId);
            colMap.put("user_id", userId);

            List<Comment> commentList = commentMapper.selectByMap(colMap);
            for (Comment comment: commentList) {
                Map<String, Object> commentMap = new HashMap<>();
                commentMap.put("userId", userId);
                commentMap.put("userName", user.getName());
                commentMap.put("time", comment.getTime().getTime());
                commentMap.put("comment", comment.getContent());
                commentMap.put("commentId", comment.getId());
                commentMap.put("newsId", newsId);
                commentMap.put("newsTitle", news.getTitle());
                allComments.add(commentMap);
            }
        }
        return allComments;
    }
}
