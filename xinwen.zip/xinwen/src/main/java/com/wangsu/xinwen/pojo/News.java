package com.wangsu.xinwen.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.ToString;
import java.sql.Timestamp;

@Data
@TableName("news")
@ToString
public class News {
    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("title")
    private String title;

    @TableField("source")
    private String source;

    @TableField("time")
    private Timestamp time;

    @TableField("img_id")
    private String imgId;

    @TableField("content")
    private String content;

    @TableField("key_name")
    private String keyName;

    @TableField("like_count")
    private Integer likeCount;

    @TableField("collect_count")
    private Integer collectCount;

    @TableField("comment_count")
    private Integer commentCount;

    @TableField("tagname")
    private String tagName;

    @TableField("heat")
    private Integer heat;

}
