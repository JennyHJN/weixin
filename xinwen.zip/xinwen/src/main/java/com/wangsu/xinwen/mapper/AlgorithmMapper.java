package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.Algorithm;
import org.apache.ibatis.annotations.Mapper;



@Mapper
public interface AlgorithmMapper extends BaseMapper<Algorithm> {
}
