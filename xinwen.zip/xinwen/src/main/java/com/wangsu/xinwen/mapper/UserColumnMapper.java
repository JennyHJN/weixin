package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.UserColumn;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserColumnMapper extends BaseMapper<UserColumn> {

    @Select("select column_id from user_column where user_id = #{userId}")
    List<Integer> getColumnIds(String userId);
}
