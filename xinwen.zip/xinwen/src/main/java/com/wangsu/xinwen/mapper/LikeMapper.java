package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.Like;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface LikeMapper extends BaseMapper<Like> {
    @Select("select count(id) from like1 where news_id = #{newsId} and  user_id = #{userId}")
    int getStatus(int newsId,  String userId);

    @Select("select news_id from like1 where user_id = #{userId}")
    List<Integer> getNewsIdByUserId(String userId);
}
