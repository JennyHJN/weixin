package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.Collection;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface CollectionMapper extends BaseMapper<Collection> {
    @Select("select count(id) from collection where news_id = #{newsId} and  user_id = #{userId}")
    int getStatus(int newsId,  String userId);

    @Select("select news_id from collection where user_id = #{userId}")
    List<Integer> getNewsIdByUserId(String userId);
}
