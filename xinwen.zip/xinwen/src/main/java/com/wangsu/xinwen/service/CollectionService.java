package com.wangsu.xinwen.service;

import com.wangsu.xinwen.mapper.CollectionMapper;
import com.wangsu.xinwen.pojo.Collection;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
@Service
public class CollectionService {

    @Resource
    private CollectionMapper collectionMapper;

    /**
     *添加收藏操作
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param userId
     * @return boolean
     */
    public boolean addCollection(int newsId, String userId){
        Collection collection = new Collection();
        collection.setNewsId(newsId);
        collection.setUserId(userId);
        Integer result = collectionMapper.insert(collection); //影响数据库行数，为0表示插入不成功
        if (result != null || result > 0) {
            return true;
        }
        return false;
    }

    /**
     *取消收藏操作
     * @author hjn
     * @date 2019/8/10
     * @param newsId
     * @param userId
     * @return boolean
     */
    public boolean deleteCollection(int newsId, String userId){
        //根据Map条件删除
        Map<String, Object> map = new HashMap<>();
        map.put("news_id", newsId);
        map.put("user_id", userId);

        Integer result = collectionMapper.deleteByMap(map);
        if (result != null || result > 0) {
            return true;
        }
        return false;
    }
}
