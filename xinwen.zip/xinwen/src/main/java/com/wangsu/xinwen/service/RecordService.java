package com.wangsu.xinwen.service;

import com.wangsu.xinwen.mapper.NewsMapper;
import com.wangsu.xinwen.mapper.RecordMapper;
import com.wangsu.xinwen.mapper.UserMapper;
import com.wangsu.xinwen.pojo.News;
import com.wangsu.xinwen.pojo.Record;
import com.wangsu.xinwen.pojo.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.Date;

@Service
public class RecordService {

    @Resource
    private RecordMapper recordMapper;
    @Resource
    private NewsMapper newsMapper;
    @Resource
    private UserMapper userMapper;

    /**
     *往record表中增加一条记录
     * @author hjn
     * @date 2019/8/8
     * @param newsId
     * @param userId
     * @return boolean数据库受影响的行数为零，说明没有插入成功；否则插入成功
     */
    public boolean addRecord(int newsId, String userId) {
        News news = newsMapper.selectById(newsId);
        if (news == null) {
            return false;
        }
        User user = userMapper.selectById(userId);
        if (user == null){
            return false;
        }
        Record record = new Record();
        record.setNewsId(newsId);
        record.setUserId(userId);
        record.setTime(new Timestamp(new Date().getTime()));

        int success = recordMapper.insert(record);
        return success != 0;
    }
}
