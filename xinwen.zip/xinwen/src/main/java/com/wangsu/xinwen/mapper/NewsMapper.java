package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.News;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NewsMapper extends BaseMapper<News> {
}
