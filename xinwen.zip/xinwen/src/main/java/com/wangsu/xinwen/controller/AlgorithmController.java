package com.wangsu.xinwen.controller;


import com.wangsu.xinwen.service.AlgorithmService;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/algorithms")
public class AlgorithmController {
    @Resource
    private AlgorithmService algorithmService;

    /**
     *根据栏目Id和用户Id获取算法列表
     * @author hjn
     * @date 2019/8/10
     * @param columnId
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllAlgorithmsByColumnId", method = RequestMethod.POST)
    public GlobalResult getAllAlgorithmsByColumnId(@RequestParam(value = "columnId", required = false) String columnId,
                                                    @RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        List<Map<String, Object>> algorithmsMap = algorithmService.getAllAlgorithmsByColumnId(Integer.parseInt(columnId), userId, 1);

        return res.build(200, "", algorithmsMap);
    }
    /**
     *根据用户Id和栏目Id获取算法列表（显示应用和未应用的）
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllAlgorithms", method = RequestMethod.POST)
    public GlobalResult getAllAlgorithms(@RequestParam(value = "columnId", required = false) String columnId,
                                         @RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        List<Map<String, Object>> algorithmsMap = algorithmService.getAllAlgorithms(Integer.parseInt(columnId), userId);
        res = res.build(200, "", algorithmsMap);
        return res;
    }

    /**
     *算法详情
     * @author hjn
     * @date 2019/8/10
     * @param algorithmId
     * @param userId
     * @param columnId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAlgorithmById", method = RequestMethod.POST)
    public GlobalResult getAlgorithmById(@RequestParam(value = "algorithmId", required = false) String algorithmId,
                                         @RequestParam(value = "userId", required = false) String userId,
                                         @RequestParam(value = "columnId", required = false) String columnId){
        GlobalResult res = new GlobalResult();
        Map<String, Object> algorithmMap = algorithmService.getAlgorithmById(algorithmId, userId, columnId);

        return res.build(200, "", algorithmMap);
    }
}
