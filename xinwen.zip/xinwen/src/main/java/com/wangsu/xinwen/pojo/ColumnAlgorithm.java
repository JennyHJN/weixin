package com.wangsu.xinwen.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.ToString;

@Data
@TableName("column_algorithm")
@ToString
public class ColumnAlgorithm {
    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("column_id")
    private Integer columnId;

    @TableField("algorithm_id")
    private Integer algorithmId;

    @TableField("user_id")
    private String userId;

    @TableField("status")
    private Boolean status;
}
