package com.wangsu.xinwen.controller;

import com.wangsu.xinwen.service.MyService;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/my")
public class MyController {
    @Resource
    private MyService myService;

    /**
     * 我的—收藏
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllFavor", method = RequestMethod.POST)
    public GlobalResult getAllFavor(@RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        List<Map<String, Object>> allFavors = myService.getAllFavor(userId);
        res = res.build(200, "", allFavors);
        return res;
    }

    /**
     *我的—点赞
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllPraise", method = RequestMethod.POST)
    public GlobalResult getAllPraise(@RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        List<Map<String, Object>> allPraises = myService.getAllPraise(userId);
        res = res.build(200, "", allPraises);
        return res;
    }

    /**
     *我的—评论
     * @author hjn
     * @date 2019/8/11
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     */
    @RequestMapping(value = "/getAllComment", method = RequestMethod.POST)
    public GlobalResult getAllComment(@RequestParam(value = "userId", required = false) String userId){
        GlobalResult res = new GlobalResult();
        List<Map<String, Object>> allAllComments = myService.getAllComment(userId);
        res = res.build(200, "", allAllComments);
        return res;
    }
}
