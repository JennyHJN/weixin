package com.wangsu.xinwen;



import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.wangsu.xinwen.mapper") //设置mapper接口的扫描包
@SpringBootApplication
public class NewsApplication {
    private static final Logger logger = LoggerFactory.getLogger(NewsApplication.class);
    public static void main(String[] args) {

        SpringApplication.run(NewsApplication.class, args);
        logger.info("========================启动完毕========================");
    }
}
