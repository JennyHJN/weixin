package com.wangsu.xinwen.utils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetAi {



    public static String requsetIP = "http://10.8.229.98:8868/add";
    /**
     * 通过http调用python接口
     *
     * @author xzp
     * @date 2019/8/11
     * @param algoName
     * @param tagName
     * @param userId
     * @return java.util.ArrayList<java.lang.String>
     */
    public static ArrayList<Integer> getNewsListByAi(String algoName, String tagName, String userId) {

        Map<String, String> requestUrlParam = new HashMap<>();
        requestUrlParam.put("algoName", algoName);
        requestUrlParam.put("tagName", tagName);
        requestUrlParam.put("userId", userId);
        String res = HttpClientUtil.doGet(requsetIP,requestUrlParam);
        String rgex = "news=(.*?)=news";
        Pattern r = Pattern.compile(rgex);
        Matcher m = r.matcher(res);
        res=res.replace("news=","");
        res=res.replace("=news","");
        String[]  result=res.split(",");
        ArrayList<Integer> result1 =new ArrayList<Integer>();
        for (String a:result) {
            if(a.equals(""))continue;
            else{
                result1.add(Integer.parseInt(a));
            }

        }
        return result1;
    }


}
