package com.wangsu.xinwen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangsu.xinwen.pojo.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

    @Select("select count(id) from comment where news_id = #{newsId}")
    int CountNumber(int newsId);

    @Select("select DISTINCT(news_id) from comment where user_id = #{userId}")
    List<Integer> getNewsIdByUserId(String userId);
}
