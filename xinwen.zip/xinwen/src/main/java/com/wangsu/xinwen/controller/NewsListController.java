package com.wangsu.xinwen.controller;

import com.wangsu.xinwen.service.NewsListService;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/news")
public class NewsListController {
    @Autowired
    private NewsListService newsListService;

    /**
     *根据栏目名columnId获取到新闻列表
     * @author xzp
     * @date 2019/8/8
     * @param columnId, columnId
     * @return
     */
    @RequestMapping(value = "/getAllNewsByColumnId", method = RequestMethod.POST)
    public GlobalResult getNewsById(@RequestParam(value = "columnId",required = false) Integer columnId,
                                    @RequestParam("start") Integer start,
                                    @RequestParam(value = "userId",required = false) String userId ){
        GlobalResult res = newsListService.getNewsListByColumnId(columnId,start,userId);

        return res;
    }


    /**
     *根据新闻ID推荐相关文章列表
     * @author xzp
     * @date 2019/8/8
     * @param newsId, columnId
     * @return
     */
    @RequestMapping(value = "/getRelationNewsById", method = RequestMethod.POST)
    public GlobalResult getRelationNewsById(@RequestParam(value = "newsId",required = false) Integer newsId,
            @RequestParam(value = "userId",required = false) String userId){
        GlobalResult res = newsListService.getRelationNewsById(newsId,userId);

        return res;
    }
}
