package com.wangsu.xinwen.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GetImgUrlUtil {

    /**
     *将图片名数组和服务器图片存放地址进行一个拼接，返回图片URL数组
     * @author hjn
     * @date 2019/8/9
     * @param imgName
     * @return java.util.ArrayList<java.lang.String>
     */
    public static ArrayList<String> getImgURL(String imgName){

        List<String> imgNames = Arrays.asList(imgName.split(","));
        if (imgNames == null || imgNames.size() == 0){
            return null;
        }
        ArrayList<String> imgURL = new ArrayList<>();
        for (String img: imgNames) {
            if (img != null && img != "" && img.length() != 0) {
                //服务器图片地址
                StringBuffer serverURL = new StringBuffer("http://10.8.148.203:8889/image/");
                imgURL.add(serverURL.append(img).toString());
            }
        }
        return imgURL;
    }
}
