package com.wangsu.xinwen.service;

import com.wangsu.xinwen.mapper.ColumnMapper;
import com.wangsu.xinwen.mapper.UserColumnMapper;
import com.wangsu.xinwen.pojo.Column;
import com.wangsu.xinwen.utils.GlobalResult;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ColumnService {
    @Resource
    private ColumnMapper columnMapper;
    @Resource
    private UserColumnMapper userColumnMapper;

    /**
     *根据用户Id获取到用户定制化的栏目名（多个）
     * @author hjn
     * @date 2019/8/9
     * @param userId
     * @return com.wangsu.xinwen.utils.GlobalResult
     * userId为空：返回user_id为"666666"的栏目名
     * userId不为空：返回该用户定制的栏目名
     */
    public GlobalResult getAllColumns(String userId){
        if (userId == null  || userId == "" || userId.length() == 0){
            userId = "666666";
        }
        List<Integer> columnIds = userColumnMapper.getColumnIds(userId);
        List<Column> columnList = columnMapper.selectBatchIds(columnIds);
        List<Map<String, Object>> columns = new ArrayList<>();
        for (Column column : columnList){
            Map<String, Object> columnMap = new HashMap<>();
            columnMap.put("name", column.getName());
            columnMap.put("id", column.getId());
            columnMap.put("order", "空空如也啊，后期实现可以加上啊！");
            columns.add(columnMap);
        }
        GlobalResult res = GlobalResult.build(200, null, columns);
        return res;
    }
}
