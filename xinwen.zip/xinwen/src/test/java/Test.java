import com.wangsu.xinwen.NewsApplication;


import com.wangsu.xinwen.utils.GetAi;
import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = NewsApplication.class)
public class Test {

    @org.junit.Test
    public void test() {
        String a="1";
        String b="新闻";
        String c="o7PSP4vJsonLtM47s1NqeDRzVt60";

        List res=GetAi.getNewsListByAi(a,b,c);
        System.out.println(res);
//       String a= "news= 520 519 518 522 517 516 523 524 525 476 478 479 475 480 481 482 483 484 497 498 499 500 495 494 493 492 491 441 442 443 444 445 446 447";
//        String rgex = "news=(.*?)";
//
//        System.out.println(getSubUtil(a,rgex));

    }
}
